import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Descola — Chat da Escola",
  description: "Comunidade oficial da Descola — Pueri Domus",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" className="h-full">
      <body className="h-full antialiased overflow-hidden">{children}</body>
    </html>
  );
}
