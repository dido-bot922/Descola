# Descola Chat

Chat estilo Discord da escola **Descola — Pueri Domus**.  
Feito com **Next.js + Supabase**, pronto para deploy no **Vercel**.

## Funcionalidades

- Login apenas com e-mails institucionais:
  - `@alunopueri.com.br` → Aluno
  - `@professorpueri.com.br` → Professor
  - `@admpueri.com.br` → Admin
- Canais de texto (agrupados por categoria)
- Mensagens em tempo real (Supabase Realtime)
- Interface escura estilo Discord
- Cargos com cores diferentes
- Canal de avisos (só professores/admins enviam)

## Setup rápido

### 1. Supabase

1. Crie um projeto em [supabase.com](https://supabase.com)
2. Vá em **SQL Editor** → New query
3. Cole todo o conteúdo de `supabase/schema.sql` e rode
4. Em **Database → Replication**, habilite Realtime na tabela `messages`
5. Em **Project Settings → API**, copie:
   - Project URL
   - `anon` `public` key

### 2. Projeto local

```bash
cd descola-chat
cp .env.example .env.local
# Edite .env.local com URL e anon key
npm install --legacy-peer-deps
npm run dev
```

Abra http://localhost:3000

### 3. Deploy no Vercel

1. Suba o repositório no GitHub
2. Importe no Vercel
3. Adicione as mesmas variáveis de ambiente:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
4. Deploy

## Estrutura

```
src/
  app/
    login/          # Tela de login/cadastro
    app/            # Chat principal
  components/       # Sidebar, MessageList, MessageInput
  lib/
    supabase/       # Clients (browser + server + middleware)
    constants.ts    # Domínios autorizados
  types/
supabase/
  schema.sql        # Tabelas + RLS + trigger de perfil
```

## Auth no Supabase

Recomendado em **Authentication → Providers → Email**:
- Desative "Confirm email" no começo (para testar mais rápido), ou deixe ativo e configure SMTP.

O trigger no `schema.sql` cria o `profile` e define o cargo pelo domínio do e-mail automaticamente.

## Próximos passos possíveis

- Upload de arquivos (Supabase Storage)
- Reações em mensagens
- Mais canais / criar canal pela UI (admin)
- Integração com voz (LiveKit) — fora do Vercel puro
