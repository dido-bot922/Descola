"use client";

import { useState, useRef, useEffect } from "react";

interface MessageInputProps {
  channelName: string;
  onSend: (content: string) => Promise<void>;
  disabled?: boolean;
}

export function MessageInput({
  channelName,
  onSend,
  disabled,
}: MessageInputProps) {
  const [content, setContent] = useState("");
  const [sending, setSending] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
  }, [content]);

  async function handleSubmit(e?: React.FormEvent) {
    e?.preventDefault();
    const trimmed = content.trim();
    if (!trimmed || sending || disabled) return;

    setSending(true);
    try {
      await onSend(trimmed);
      setContent("");
      if (textareaRef.current) {
        textareaRef.current.style.height = "auto";
      }
    } finally {
      setSending(false);
    }
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  }

  return (
    <div className="px-4 pb-6">
      <form
        onSubmit={handleSubmit}
        className="bg-[#383a40] rounded-lg flex items-end gap-2 px-4 py-2.5"
      >
        <textarea
          ref={textareaRef}
          value={content}
          onChange={(e) => setContent(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={`Conversar em #${channelName}`}
          disabled={disabled || sending}
          rows={1}
          className="flex-1 bg-transparent text-[#dbdee1] placeholder:text-[#6d6f78] outline-none resize-none max-h-[200px] text-[15px] leading-5 py-1"
        />
        <button
          type="submit"
          disabled={!content.trim() || sending || disabled}
          className="text-[#b5bac1] hover:text-white disabled:opacity-40 disabled:hover:text-[#b5bac1] pb-1 transition-colors"
          title="Enviar"
        >
          <svg
            className="w-5 h-5"
            fill="currentColor"
            viewBox="0 0 24 24"
          >
            <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" />
          </svg>
        </button>
      </form>
      <p className="text-[11px] text-[#6d6f78] mt-1.5 px-1">
        Enter para enviar · Shift+Enter para nova linha
      </p>
    </div>
  );
}
