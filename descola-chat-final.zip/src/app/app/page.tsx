"use client";

import { useEffect, useState, useCallback } from "react";
import { createClient } from "@/lib/supabase/client";
import { Sidebar } from "@/components/Sidebar";
import { MessageList } from "@/components/MessageList";
import { MessageInput } from "@/components/MessageInput";
import type { Channel, Message, Profile } from "@/types/database";
import { Hash, Megaphone } from "lucide-react";

export default function AppPage() {
  const supabase = createClient();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [activeChannelId, setActiveChannelId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const activeChannel = channels.find((c) => c.id === activeChannelId) || null;

  // Carrega perfil + canais
  useEffect(() => {
    let cancelled = false;

    async function init() {
      setLoading(true);
      setError(null);

      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        setLoading(false);
        return;
      }

      const { data: prof, error: profErr } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .single();

      if (profErr) {
        setError("Erro ao carregar perfil. Rode o schema.sql no Supabase?");
        setLoading(false);
        return;
      }

      const { data: chans, error: chanErr } = await supabase
        .from("channels")
        .select("*")
        .order("position", { ascending: true });

      if (chanErr) {
        setError("Erro ao carregar canais: " + chanErr.message);
        setLoading(false);
        return;
      }

      if (!cancelled) {
        setProfile(prof);
        setChannels(chans || []);
        if (chans && chans.length > 0) {
          setActiveChannelId(chans[0].id);
        }
        setLoading(false);
      }
    }

    init();
    return () => {
      cancelled = true;
    };
  }, [supabase]);

  // Carrega mensagens do canal ativo + realtime
  useEffect(() => {
    if (!activeChannelId) {
      setMessages([]);
      return;
    }

    let cancelled = false;

    async function loadMessages() {
      const { data, error: err } = await supabase
        .from("messages")
        .select("*, profiles(*)")
        .eq("channel_id", activeChannelId)
        .order("created_at", { ascending: true })
        .limit(200);

      if (err) {
        console.error(err);
        return;
      }
      if (!cancelled) setMessages(data || []);
    }

    loadMessages();

    const channel = supabase
      .channel(`messages:${activeChannelId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `channel_id=eq.${activeChannelId}`,
        },
        async (payload) => {
          const newMsg = payload.new as Message;
          // Busca perfil do autor
          const { data: prof } = await supabase
            .from("profiles")
            .select("*")
            .eq("id", newMsg.user_id)
            .single();
          setMessages((prev) => {
            if (prev.some((m) => m.id === newMsg.id)) return prev;
            return [...prev, { ...newMsg, profiles: prof }];
          });
        }
      )
      .subscribe();

    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
    };
  }, [activeChannelId, supabase]);

  const handleSend = useCallback(
    async (content: string) => {
      if (!activeChannelId || !profile) return;

      const { error: err } = await supabase.from("messages").insert({
        channel_id: activeChannelId,
        user_id: profile.id,
        content,
      });

      if (err) {
        console.error(err);
        alert("Erro ao enviar: " + err.message);
      }
    },
    [activeChannelId, profile, supabase]
  );

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center bg-[#313338] text-[#949ba4]">
        Carregando Descola...
      </div>
    );
  }

  if (error) {
    return (
      <div className="h-full flex flex-col items-center justify-center bg-[#313338] text-center px-4">
        <p className="text-red-400 mb-2">{error}</p>
        <p className="text-sm text-[#949ba4] max-w-md">
          Abra o Supabase → SQL Editor → cole e execute o arquivo{" "}
          <code className="text-[#dbdee1]">supabase/schema.sql</code>. Depois
          habilite Realtime na tabela <code className="text-[#dbdee1]">messages</code>.
        </p>
      </div>
    );
  }

  const Icon =
    activeChannel?.type === "announcement" ? Megaphone : Hash;

  return (
    <div className="h-full flex bg-[#313338]">
      <Sidebar
        channels={channels}
        activeChannelId={activeChannelId}
        onSelectChannel={setActiveChannelId}
        profile={profile}
      />

      <main className="flex-1 flex flex-col min-w-0">
        {/* Header do canal */}
        <header className="h-12 px-4 flex items-center gap-2 shadow-md border-b border-[#1e1f22] flex-shrink-0">
          {activeChannel ? (
            <>
              <Icon className="w-5 h-5 text-[#949ba4]" />
              <span className="font-semibold text-white">
                {activeChannel.name}
              </span>
              {activeChannel.description && (
                <>
                  <span className="text-[#3f4147]">|</span>
                  <span className="text-sm text-[#949ba4] truncate">
                    {activeChannel.description}
                  </span>
                </>
              )}
            </>
          ) : (
            <span className="text-[#949ba4]">Selecione um canal</span>
          )}
        </header>

        {activeChannel ? (
          <>
            <MessageList
              messages={messages}
              channelName={activeChannel.name}
            />
            <MessageInput
              channelName={activeChannel.name}
              onSend={handleSend}
              disabled={
                activeChannel.type === "announcement" &&
                profile?.role === "aluno"
              }
            />
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-[#949ba4]">
            Nenhum canal disponível
          </div>
        )}
      </main>
    </div>
  );
}
