"use client";

import { useEffect, useRef } from "react";
import type { Message } from "@/types/database";
import { ROLE_COLORS, ROLE_LABELS } from "@/lib/constants";
import { format, isToday, isYesterday } from "date-fns";
import { ptBR } from "date-fns/locale";

interface MessageListProps {
  messages: Message[];
  channelName: string;
}

function formatDay(dateStr: string) {
  const d = new Date(dateStr);
  if (isToday(d)) return "Hoje";
  if (isYesterday(d)) return "Ontem";
  return format(d, "d 'de' MMMM 'de' yyyy", { locale: ptBR });
}

function formatTime(dateStr: string) {
  return format(new Date(dateStr), "HH:mm");
}

export function MessageList({ messages, channelName }: MessageListProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  let lastDay = "";

  return (
    <div className="flex-1 overflow-y-auto px-4 py-4">
      {messages.length === 0 ? (
        <div className="h-full flex flex-col items-center justify-center text-[#949ba4]">
          <div className="w-16 h-16 rounded-full bg-[#404249] flex items-center justify-center text-3xl mb-4">
            #
          </div>
          <p className="text-xl font-semibold text-white">
            Bem-vindo a #{channelName}!
          </p>
          <p className="text-sm mt-1">
            Este é o início do canal. Envie a primeira mensagem.
          </p>
        </div>
      ) : (
        <div className="space-y-1">
          {messages.map((msg) => {
            const day = formatDay(msg.created_at);
            const showDivider = day !== lastDay;
            lastDay = day;
            const profile = msg.profiles;
            const name = profile?.display_name || profile?.email || "Usuário";
            const role = profile?.role;

            return (
              <div key={msg.id}>
                {showDivider && (
                  <div className="flex items-center gap-2 my-4">
                    <div className="flex-1 h-px bg-[#3f4147]" />
                    <span className="text-xs text-[#949ba4] font-semibold px-2">
                      {day}
                    </span>
                    <div className="flex-1 h-px bg-[#3f4147]" />
                  </div>
                )}
                <div className="group flex gap-3 py-0.5 px-2 -mx-2 rounded hover:bg-[#2e3035]">
                  <div className="w-10 h-10 rounded-full bg-[#5865f2] flex items-center justify-center text-white font-medium flex-shrink-0 mt-0.5">
                    {name[0]?.toUpperCase()}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-baseline gap-2 flex-wrap">
                      <span className="font-medium text-white hover:underline cursor-default">
                        {name}
                      </span>
                      {role && (
                        <span
                          className={`text-[10px] font-semibold uppercase ${ROLE_COLORS[role]}`}
                        >
                          {ROLE_LABELS[role]}
                        </span>
                      )}
                      <span className="text-xs text-[#949ba4]">
                        {formatTime(msg.created_at)}
                        {msg.edited && " (editado)"}
                      </span>
                    </div>
                    <p className="text-[#dbdee1] text-[15px] leading-relaxed whitespace-pre-wrap break-words">
                      {msg.content}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={bottomRef} />
        </div>
      )}
    </div>
  );
}
