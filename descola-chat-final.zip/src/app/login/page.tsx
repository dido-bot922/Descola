"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { isAuthorizedEmail } from "@/lib/constants";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const router = useRouter();
  const supabase = createClient();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setMessage(null);
    setLoading(true);

    const normalized = email.trim().toLowerCase();

    if (!isAuthorizedEmail(normalized)) {
      setError(
        "Use apenas e-mail institucional: @alunopueri.com.br, @professorpueri.com.br ou @admpueri.com.br"
      );
      setLoading(false);
      return;
    }

    try {
      if (mode === "login") {
        const { error: err } = await supabase.auth.signInWithPassword({
          email: normalized,
          password,
        });
        if (err) throw err;
        router.push("/app");
        router.refresh();
      } else {
        if (!displayName.trim()) {
          setError("Informe seu nome de exibição");
          setLoading(false);
          return;
        }
        const { error: err } = await supabase.auth.signUp({
          email: normalized,
          password,
          options: {
            data: { display_name: displayName.trim() },
          },
        });
        if (err) throw err;
        setMessage(
          "Conta criada! Verifique seu e-mail se a confirmação estiver ativa, ou faça login."
        );
        setMode("login");
      }
    } catch (err: unknown) {
      const msg =
        err instanceof Error ? err.message : "Erro ao autenticar. Tente de novo.";
      setError(msg);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-full flex items-center justify-center bg-[#1e1f22] p-4">
      <div className="w-full max-w-md bg-[#313338] rounded-lg shadow-xl p-8 border border-[#1e1f22]">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-[#5865f2] text-white text-2xl font-bold mb-4">
            D
          </div>
          <h1 className="text-2xl font-bold text-white">Descola</h1>
          <p className="text-[#949ba4] mt-1 text-sm">
            Chat oficial — Pueri Domus
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === "signup" && (
            <div>
              <label className="block text-xs font-semibold text-[#b5bac1] uppercase mb-1.5">
                Nome de exibição
              </label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full bg-[#1e1f22] text-[#dbdee1] rounded px-3 py-2.5 outline-none focus:ring-2 focus:ring-[#5865f2] border border-transparent"
                placeholder="Seu nome"
                autoComplete="name"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-[#b5bac1] uppercase mb-1.5">
              E-mail institucional
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-[#1e1f22] text-[#dbdee1] rounded px-3 py-2.5 outline-none focus:ring-2 focus:ring-[#5865f2] border border-transparent"
              placeholder="seuemail@alunopueri.com.br"
              required
              autoComplete="email"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#b5bac1] uppercase mb-1.5">
              Senha
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-[#1e1f22] text-[#dbdee1] rounded px-3 py-2.5 outline-none focus:ring-2 focus:ring-[#5865f2] border border-transparent"
              placeholder="••••••••"
              required
              minLength={6}
              autoComplete={mode === "login" ? "current-password" : "new-password"}
            />
          </div>

          {error && (
            <div className="text-sm text-red-400 bg-red-400/10 rounded px-3 py-2">
              {error}
            </div>
          )}
          {message && (
            <div className="text-sm text-emerald-400 bg-emerald-400/10 rounded px-3 py-2">
              {message}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#5865f2] hover:bg-[#4752c4] disabled:opacity-50 text-white font-medium rounded py-2.5 transition-colors"
          >
            {loading
              ? "Aguarde..."
              : mode === "login"
                ? "Entrar"
                : "Criar conta"}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-[#949ba4]">
          {mode === "login" ? (
            <>
              Não tem conta?{" "}
              <button
                type="button"
                onClick={() => {
                  setMode("signup");
                  setError(null);
                  setMessage(null);
                }}
                className="text-[#00a8fc] hover:underline"
              >
                Cadastre-se
              </button>
            </>
          ) : (
            <>
              Já tem conta?{" "}
              <button
                type="button"
                onClick={() => {
                  setMode("login");
                  setError(null);
                  setMessage(null);
                }}
                className="text-[#00a8fc] hover:underline"
              >
                Entrar
              </button>
            </>
          )}
        </p>

        <p className="mt-4 text-center text-xs text-[#6d6f78]">
          Apenas e-mails @alunopueri / @professorpueri / @admpueri
        </p>
      </div>
    </div>
  );
}
