/** Domínios de e-mail autorizados da escola */
export const AUTHORIZED_DOMAINS = [
  "alunopueri.com.br",
  "professorpueri.com.br",
  "admpueri.com.br",
] as const;

export type SchoolRole = "aluno" | "professor" | "admin";

export function isAuthorizedEmail(email: string): boolean {
  const domain = email.split("@")[1]?.toLowerCase();
  return AUTHORIZED_DOMAINS.includes(
    domain as (typeof AUTHORIZED_DOMAINS)[number]
  );
}

export function roleFromEmail(email: string): SchoolRole {
  const domain = email.split("@")[1]?.toLowerCase();
  if (domain === "admpueri.com.br") return "admin";
  if (domain === "professorpueri.com.br") return "professor";
  return "aluno";
}

export const ROLE_LABELS: Record<SchoolRole, string> = {
  aluno: "Aluno",
  professor: "Professor",
  admin: "Admin",
};

export const ROLE_COLORS: Record<SchoolRole, string> = {
  aluno: "text-emerald-400",
  professor: "text-sky-400",
  admin: "text-rose-400",
};
