"use client";

import type { Channel, Profile } from "@/types/database";
import { ROLE_COLORS, ROLE_LABELS } from "@/lib/constants";
import { Hash, Megaphone, LogOut } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

interface SidebarProps {
  channels: Channel[];
  activeChannelId: string | null;
  onSelectChannel: (id: string) => void;
  profile: Profile | null;
}

export function Sidebar({
  channels,
  activeChannelId,
  onSelectChannel,
  profile,
}: SidebarProps) {
  const router = useRouter();
  const supabase = createClient();

  const byCategory = channels.reduce<Record<string, Channel[]>>((acc, ch) => {
    const cat = ch.category || "Geral";
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(ch);
    return acc;
  }, {});

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push("/login");
    router.refresh();
  }

  return (
    <aside className="w-60 flex-shrink-0 bg-[#2b2d31] flex flex-col h-full">
      <div className="h-12 px-4 flex items-center shadow-md border-b border-[#1e1f22] font-semibold text-white truncate">
        Descola — Pueri Domus
      </div>

      <div className="flex-1 overflow-y-auto pt-3 pb-2 px-2 space-y-4">
        {Object.entries(byCategory).map(([category, list]) => (
          <div key={category}>
            <div className="px-2 mb-1 text-[11px] font-semibold uppercase tracking-wide text-[#949ba4] flex items-center gap-1">
              {category}
            </div>
            <ul className="space-y-0.5">
              {list
                .sort((a, b) => a.position - b.position)
                .map((ch) => {
                  const active = ch.id === activeChannelId;
                  const Icon = ch.type === "announcement" ? Megaphone : Hash;
                  return (
                    <li key={ch.id}>
                      <button
                        type="button"
                        onClick={() => onSelectChannel(ch.id)}
                        className={`w-full flex items-center gap-1.5 px-2 py-1.5 rounded text-left text-[15px] transition-colors ${
                          active
                            ? "bg-[#404249] text-white"
                            : "text-[#949ba4] hover:bg-[#35373c] hover:text-[#dbdee1]"
                        }`}
                      >
                        <Icon className="w-4 h-4 flex-shrink-0 opacity-70" />
                        <span className="truncate">{ch.name}</span>
                      </button>
                    </li>
                  );
                })}
            </ul>
          </div>
        ))}
      </div>

      <div className="h-14 bg-[#232428] px-2 flex items-center gap-2">
        <div className="w-8 h-8 rounded-full bg-[#5865f2] flex items-center justify-center text-white text-sm font-medium flex-shrink-0">
          {(profile?.display_name || profile?.email || "?")[0]?.toUpperCase()}
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-sm font-medium text-white truncate">
            {profile?.display_name || "Usuário"}
          </div>
          <div
            className={`text-xs truncate ${
              profile ? ROLE_COLORS[profile.role] : "text-[#949ba4]"
            }`}
          >
            {profile ? ROLE_LABELS[profile.role] : "…"}
          </div>
        </div>
        <button
          type="button"
          onClick={handleLogout}
          title="Sair"
          className="p-1.5 rounded text-[#b5bac1] hover:bg-[#35373c] hover:text-white"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </aside>
  );
}
