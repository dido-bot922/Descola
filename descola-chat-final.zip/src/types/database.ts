export type SchoolRole = "aluno" | "professor" | "admin";

export interface Profile {
  id: string;
  email: string;
  display_name: string | null;
  avatar_url: string | null;
  role: SchoolRole;
  created_at: string;
  updated_at: string;
}

export interface Channel {
  id: string;
  name: string;
  description: string | null;
  type: "text" | "announcement";
  category: string | null;
  position: number;
  is_private: boolean;
  created_by: string | null;
  created_at: string;
}

export interface Message {
  id: string;
  channel_id: string;
  user_id: string;
  content: string;
  created_at: string;
  updated_at: string;
  edited: boolean;
  profiles?: Profile | null;
}
