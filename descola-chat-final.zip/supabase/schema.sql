-- ============================================================
-- DESCOLA CHAT - Schema Supabase
-- Rode este SQL no SQL Editor do Supabase (uma vez)
-- ============================================================

-- Extensões
create extension if not exists "pgcrypto";

-- Perfis (estende auth.users)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  display_name text,
  avatar_url text,
  role text not null default 'aluno'
    check (role in ('aluno', 'professor', 'admin')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Canais (estilo Discord)
create table if not exists public.channels (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  type text not null default 'text'
    check (type in ('text', 'announcement')),
  category text default 'Geral',
  position int not null default 0,
  is_private boolean not null default false,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

-- Mensagens
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  channel_id uuid not null references public.channels(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  edited boolean not null default false
);

-- Índices
create index if not exists messages_channel_id_created_at_idx
  on public.messages (channel_id, created_at desc);

create index if not exists channels_position_idx
  on public.channels (position);

-- ============================================================
-- RLS (Row Level Security)
-- ============================================================

alter table public.profiles enable row level security;
alter table public.channels enable row level security;
alter table public.messages enable row level security;

-- Profiles
create policy "Profiles are viewable by authenticated users"
  on public.profiles for select
  to authenticated
  using (true);

create policy "Users can update own profile"
  on public.profiles for update
  to authenticated
  using (auth.uid() = id);

-- Channels
create policy "Channels are viewable by authenticated users"
  on public.channels for select
  to authenticated
  using (true);

create policy "Admins and professors can create channels"
  on public.channels for insert
  to authenticated
  with check (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and role in ('admin', 'professor')
    )
  );

create policy "Admins can update/delete channels"
  on public.channels for update
  to authenticated
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and role = 'admin'
    )
  );

create policy "Admins can delete channels"
  on public.channels for delete
  to authenticated
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and role = 'admin'
    )
  );

-- Messages
create policy "Messages are viewable by authenticated users"
  on public.messages for select
  to authenticated
  using (true);

create policy "Authenticated users can insert messages"
  on public.messages for insert
  to authenticated
  with check (auth.uid() = user_id);

create policy "Users can update own messages"
  on public.messages for update
  to authenticated
  using (auth.uid() = user_id);

create policy "Users can delete own messages or admins any"
  on public.messages for delete
  to authenticated
  using (
    auth.uid() = user_id
    or exists (
      select 1 from public.profiles
      where id = auth.uid() and role = 'admin'
    )
  );

-- ============================================================
-- Trigger: criar profile automaticamente no signup
-- ============================================================

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  domain text;
  assigned_role text := 'aluno';
begin
  domain := split_part(new.email, '@', 2);

  if domain = 'admpueri.com.br' then
    assigned_role := 'admin';
  elsif domain = 'professorpueri.com.br' then
    assigned_role := 'professor';
  elsif domain = 'alunopueri.com.br' then
    assigned_role := 'aluno';
  else
    -- Bloqueia e-mails fora da escola (também validamos no frontend)
    raise exception 'E-mail não autorizado. Use um e-mail institucional da Descola/Pueri.';
  end if;

  insert into public.profiles (id, email, display_name, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1)),
    assigned_role
  );

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ============================================================
-- Realtime
-- ============================================================

-- Habilite Realtime nas tabelas no dashboard:
-- Database → Replication → messages (e channels se quiser)

-- Canais iniciais de exemplo
insert into public.channels (name, description, category, position, type)
values
  ('geral', 'Conversas gerais da Descola', 'Geral', 0, 'text'),
  ('avisos', 'Avisos oficiais da coordenação', 'Geral', 1, 'announcement'),
  ('dúvidas', 'Tire suas dúvidas com professores e colegas', 'Acadêmico', 2, 'text'),
  ('trabalhos', 'Entrega e discussão de trabalhos', 'Acadêmico', 3, 'text')
on conflict do nothing;
